/* */ 
module.exports = require('./defineProperty');
