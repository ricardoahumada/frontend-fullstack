/* */ 
"use strict";

exports.__esModule = true;

exports.default = function (obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
};