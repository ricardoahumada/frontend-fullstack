/* */ 
module.exports = require('./temporalUndefined');
