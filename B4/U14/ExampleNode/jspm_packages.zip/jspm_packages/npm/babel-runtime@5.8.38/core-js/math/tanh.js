/* */ 
module.exports = { "default": require("core-js/library/fn/math/tanh"), __esModule: true };