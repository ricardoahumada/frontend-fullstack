/* */ 
module.exports = { "default": require("core-js/library/fn/weak-map"), __esModule: true };