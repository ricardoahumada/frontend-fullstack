/* */ 
module.exports = { "default": require("core-js/library/fn/set-immediate"), __esModule: true };