/* */ 
module.exports = { "default": require("core-js/library/fn/number/parse-float"), __esModule: true };