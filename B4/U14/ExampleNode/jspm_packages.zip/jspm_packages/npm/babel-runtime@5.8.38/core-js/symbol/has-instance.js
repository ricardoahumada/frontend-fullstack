/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/has-instance"), __esModule: true };