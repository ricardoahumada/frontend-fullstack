/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/set"), __esModule: true };