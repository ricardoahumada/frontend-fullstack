/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/is-concat-spreadable"), __esModule: true };