/* */ 
module.exports = { "default": require("core-js/library/fn/map"), __esModule: true };