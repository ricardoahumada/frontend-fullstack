/* */ 
module.exports = { "default": require("core-js/library/fn/array/copy-within"), __esModule: true };