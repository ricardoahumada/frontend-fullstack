/* */ 
require('../../modules/es6.function.name');
require('../../modules/es6.function.has-instance');
require('../../modules/core.function.part');
module.exports = require('../../modules/$.core').Function;
