/* */ 
module.exports = require('./html-collection/index');
