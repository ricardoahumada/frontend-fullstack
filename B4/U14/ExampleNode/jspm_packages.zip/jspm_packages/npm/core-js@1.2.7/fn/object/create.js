/* */ 
var $ = require('../../modules/$');
module.exports = function create(P, D) {
  return $.create(P, D);
};
